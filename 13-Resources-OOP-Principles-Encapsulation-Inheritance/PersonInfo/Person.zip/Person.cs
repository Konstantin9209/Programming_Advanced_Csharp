﻿using System;

namespace PersonInfo;

public class Person
{
    private string _FirstName;
    private string _LastName;
    private int _age;

    private const int NAME_MIN_LENGTH = 3;

    public Person(string firstName, string lastName, int age)
    {
        this._FirstName = firstName;
        this._LastName = lastName;
        this._age = age;
    }

    public string FirstName
    {
        get { return _FirstName; }
        private set
        {
            if (value.Length < NAME_MIN_LENGTH)
            {
                throw new ArgumentException($"FIrst name cannon contain fewer than {NAME_MIN_LENGTH} symbols!");
            }
            this._FirstName = value;
        }
    }
    public string LastName
    {
        get { return _LastName; }
        private set
        {
            if (value.Length < NAME_MIN_LENGTH)
            {
                throw new ArgumentException($"Last name cannon contain fewer than {NAME_MIN_LENGTH} symbols!");
            }
            this._LastName = value;
        }
    }
        public int Age
    {
        get { return this.Age; }
        private set
        {
            if (value <= 0)
            {
                throw new ArgumentException("Age cannot be zero or negative integer!");
            }
            this.Age = value;


        }
    }

    public override string ToString()
    {
        return $"{this.FirstName} {this.LastName} is {this.Age} years old.";
    }

}


